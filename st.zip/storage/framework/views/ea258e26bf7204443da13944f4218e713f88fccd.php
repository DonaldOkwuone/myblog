<?php $__env->startSection('content'); ?>
 
	<div class="about">
		<div class="container">
			<div class="about-main">
				<div class="col-md-8 about-left">
					<div class="about-one">
						<p>Find The Most</p>
						<h3><?php echo e($posts[0]->title); ?></h3>
					</div>
					<div class="about-two">
						<a href="single.html"><img src="images/c-1.jpg" alt="" /></a>
						<p>Posted by <a href="#"><?php echo e($posts[0]->author); ?></a> on <?php echo e($posts[0]->added_on); ?> <a href="#">comments(2)</a></p>
						<p> <?php echo e($posts[0]->body); ?></p>
						<div class="about-btn">
							<a href="/blog/<?php echo $posts[0]->id; ?>">Read More</a>
						</div>
						<ul>
							<li><p>Share : </p></li>
							<li><a href="#"><span class="fb"> </span></a></li>
							<li><a href="#"><span class="twit"> </span></a></li>
							<li><a href="#"><span class="pin"> </span></a></li>
							<li><a href="#"><span class="rss"> </span></a></li>
							<li><a href="#"><span class="drbl"> </span></a></li>
						</ul>
					</div>	
					<div class="about-tre">
						
							<div class="a-1">
							
								<?php foreach($posts as $post): ?>
									<div class="col-md-6 abt-left">
										<a href="single.html"><img src="images/c-3.jpg" alt="" /></a>
										<h6> Arsenal Break</h6>
										
										<?php $new_title = substr($post->title , 0, 20); ?>
										<?php $new_title = $new_title." ..."; ?>
										
										<h3><a href="/blog/<?php echo $post->id; ?>"><?php echo e($new_title); ?></a></h3>
										<?php $new_str = substr($post->body , 0, 50); ?>
										<?php $new_str = $new_str." ..."; ?>
										<p><?php echo e($new_str); ?></p>
										<label><?php echo e($post->added_on); ?></label>
									</div>
								<?php endforeach; ?>
								
								<div class="clearfix"></div>
							</div>
						
						 
						
					</div>	
				</div>
				<div class="col-md-4 about-right heading">
					<div class="abt-1">
						<h3>ABOUT US</h3>
						<div class="abt-one">
							<img src="images/c-2.jpg" alt="" />
							<p> Need to listen to random ramblings about Arsenal FC., look no further!</p>
							<div class="a-btn">
								<a href="<?php echo e(url('/about-us')); ?>">Read More</a>
							</div>
						</div>
					</div>
					<div class="abt-2">
						<h3>Most Read</h3>
						<?php foreach($most_read as $post): ?>
							<div class="might-grid">
								<div class="grid-might">
									<a href=" <?php echo e(url('/blog/'.$post->id)); ?> "><img src="images/c-12.jpg" class="img-responsive" alt=""> </a>
								</div>
								<div class="might-top">
									<h4><a href="<?php echo e(url('/blog/'.$post->id)); ?>"> <?php echo e($post->title); ?> </a></h4>
									<?php @$new_str = substr($post->body , 0, 50); ?>
									<?php @$new_str = $new_str." ..."; ?>
									<p> <?php echo e($new_str); ?> </p> 
								</div>
								<div class="clearfix"></div>
							</div>
						<?php endforeach; ?>
							 							
					</div>
					<div class="abt-2">
						<h3>ARCHIVES</h3>
						<ul>
							<li><a href="single.html">Lorem Ipsum is simply dummy text of the printing and typesetting industry. </a></li>
							<li><a href="single.html">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</a></li>
							<li><a href="single.html">When an unknown printer took a galley of type and scrambled it to make a type specimen book. </a> </li>
							<li><a href="single.html">It has survived not only five centuries, but also the leap into electronic typesetting</a> </li>
							<li><a href="single.html">Remaining essentially unchanged. It was popularised in the 1960s with the release of </a> </li>
							<li><a href="single.html">Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing </a> </li>
							<li><a href="single.html">Software like Aldus PageMaker including versionsof Lorem Ipsum.</a> </li>
						</ul>	
					</div>
					<div class="abt-2">
						<h3>NEWS LETTER</h3>
						<div class="news">
							<form>
								<input type="text" value="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}" />
								<input type="submit" value="Subscribe">
							</form>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>			
			</div>		
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('blog.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>