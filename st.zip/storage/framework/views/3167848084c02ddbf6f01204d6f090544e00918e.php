<?php $__env->startSection('content'); ?>

	<?php 
		echo Form::open(array('url' => '/admin/'.$post->id ,'files'=>'true'));
	?>
	<input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
	<input type="hidden" name="_method" value="put">

	<div class="form-group">
		<label for="title">Title</label>
		<input type="text" class="form-control" value="<?php echo e($post->title); ?>" name="title" id="title" placeholder="Title of Post">
	</div>
	<div class="form-group">
		<label for="author">Author</label>
		<input type="text" class="form-control" value="<?php echo e($post->author); ?>" name="author" id="author" placeholder="author">
	</div>
	<div class="form-group">
		<label for="body">Body</label>
		<textarea id="body" name="body"  placeholder="Body of Post" class="form-control" rows="3"><?php echo e($post->body); ?> </textarea> 
	</div>

	<div class="form-group">
		<label for="category">Category</label>
		<select  class="form-control" name="category" >
		<?php foreach($categories as $category): ?>
			 
				<option <?php if($category == $cat){ echo "selected"; } ?> value="<?php echo $category->id ?>" ><?php echo $category->title ?></option>
			 
		<?php endforeach; ?>
	</select>
	</div>
 
	  <div class="form-group">
		<label for="image">Featured Image</label> 
		<input type="file" id="image" name="image" >
		<p class="help-block">Upload an image associated with post</p>
	  </div>
	  
	  
	  <div class="checkbox">
		<label>
		  <input <?php if($post->published == 1){ echo "checked"; } ?> type="checkbox" name="published" value="1"> Publish Now? 
		</label>
	  </div>
	  
	  
	  <button type="submit" class="btn btn-default">Submit</button>
	<?php 
		echo Form::close();
	?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>