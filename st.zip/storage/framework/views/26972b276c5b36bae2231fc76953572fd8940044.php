 
 <?php $__env->startSection('content'); ?>
 <h1 class="page-header">Dashboard</h1>
<?php if(Session::has('message')): ?>
		<div class="alert alert-danger">
			<ul>
				 
					<li><?php echo e(Session::get('message')); ?></li>
				 
			</ul>
		</div>
	<?php endif; ?>
          <h2 class="sub-header">Blog Posts </h2>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Title</th>
                  <th>Posted By</th>
                  <th>Publish Date</th>
                  <th>Hits</th>
                </tr>
              </thead>
              <tbody>
                 
               <?php foreach($posts as $post ): ?> 
                
                <tr>
				  <td><?php echo e($post->id); ?></td>
                  <td><?php echo e($post->title); ?></td>
                  <td><?php echo e($post->author); ?></td>
                  <td><?php echo e($post->added_on); ?></td>
                  <td><?php echo e($post->hits); ?></td>
                  <td><a href="/admin/<?php echo $post->id; ?>">EDIT</a></td>
                  <td>
					<form action="/admin/<?php echo e($post->id); ?>" method="post" >
						
						<input type="hidden" name="_method" value="delete" >
						<input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
						<input type="submit" name="submit" value="Delete">
						
					</form>
				  </td> 
                   
                </tr>
			  <?php endforeach; ?>		
              </tbody>
            </table>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>